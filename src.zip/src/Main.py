from Labyrinth import *
from threeDLabyrinth import *
from fourthDLabyrinth import *

#lab = Labyrinth(10, 0)
#lab.printLab()
#lab.findWay(0,99)
#lab.labToTxt()

#lab2 = threeDLabyrinth(13, 0)
#lab2.printLab()
#lab2.findWay(0,2)

lab3 = fourthDLabyrinth(3,0)
lab3.printLab()
lab3.findWay(0,2)






